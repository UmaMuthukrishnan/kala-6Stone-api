package com.kalah.rest.service;

import com.kalah.rest.model.KalahGame;
import com.kalah.rest.model.enums.KalahBoard;
import com.kalah.rest.repository.GameRepository;
import com.kalah.rest.repository.InMemoryGameRepository;
import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.IntStream;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.Assert.*;

@SpringBootTest
public class KalahGameBoardFacadeTest {

    private KalahGameBoardFacade kalahGameBoardFacade;

    private Map<Integer, Integer> gameBoard;

    private final GameRepository gameRepository = InMemoryGameRepository.getInstance();

    private Class<? extends KalahGameBoardFacade> kalahGameBoard;

    @Before
    public void setUp() {
        kalahGameBoardFacade = new KalahGameBoardFacade();
        kalahGameBoard = kalahGameBoardFacade.getClass();
        gameBoard = new HashMap<>();
    }

    @Test
    public void testForInitializingGameBoard() {
        kalahGameBoardFacade.initializeGameBoard(gameBoard);
        assertEquals(14, gameBoard.size());
        IntStream.rangeClosed(KalahBoard.FIRST_PIT_INDEX.getValue(), KalahBoard.SECOND_KALAH_INDEX.getValue())
                .forEach(pit -> {
                    int noOfStones = gameBoard.get(pit);
                    if (pit == KalahBoard.FIRST_KALAH_INDEX.getValue() || pit == KalahBoard.SECOND_KALAH_INDEX.getValue()) {
                        assertEquals(0, noOfStones);
                    } else {
                        assertEquals(6, noOfStones);
                    }
                });
        gameBoard.forEach((pit, value) -> {
            if (pit == KalahBoard.FIRST_KALAH_INDEX.getValue() || pit == KalahBoard.SECOND_KALAH_INDEX.getValue()) {
                assertEquals(0, gameBoard.get(pit).intValue());
            } else {
                assertEquals(6, gameBoard.get(pit).intValue());
            }
        });
    }

    @Test
    public void testForMovingPitStones() {
        int pitId = 3;
        gameBoard = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(gameBoard);
        KalahGame game = KalahGame.builder()
                .id(1234).board(gameBoard)
                .status(KalahGame.GameStatus.IN_PROGRESS)
                .player(KalahGame.Player.FIRST_PLAYER)
                .build();
        gameRepository.save(game);
        int pitStoneCount = gameBoard.get(pitId);
        Map<Integer, Integer> beforeMove = new HashMap<>(gameBoard);
        kalahGameBoardFacade.movePitStones(pitId, game);

        IntStream.range(pitId + 1, pitStoneCount + 1).forEach(pit -> {
            int stoneCount = gameBoard.get(pit);
            assertEquals(stoneCount, beforeMove.get(pit) + 1);
        });
    }

    @Test
    public void testForGameTermination() throws Exception {
        Method gameIsTerminated = kalahGameBoard.getDeclaredMethod("isGameTerminated", KalahGame.class);
        privateMethodForTest(gameIsTerminated);

        gameBoard = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(gameBoard);
        KalahGame game = KalahGame.builder()
                .id(1234).board(gameBoard)
                .status(KalahGame.GameStatus.IN_PROGRESS)
                .player(KalahGame.Player.FIRST_PLAYER)
                .build();
        gameRepository.save(game);

        boolean falseResult = (boolean) gameIsTerminated.invoke(kalahGameBoardFacade, game);
        assertFalse(falseResult);


        gameBoard.forEach((pit, stone) -> gameBoard.put(pit, 0));
        game.setBoard(gameBoard);
        gameRepository.save(game);

        boolean trueResult = (boolean) gameIsTerminated.invoke(kalahGameBoardFacade, game);
        assertTrue(trueResult);
    }

    @Test
    public void testIsUserPit() throws Exception {
        Method isUserPit = kalahGameBoard.getDeclaredMethod("isUserPit", int.class, KalahGame.Player.class);
        privateMethodForTest(isUserPit);
        boolean isFirstPlayerPit = (boolean) isUserPit.invoke(kalahGameBoardFacade, 12, KalahGame.Player.FIRST_PLAYER);
        assertFalse(isFirstPlayerPit);

        boolean isSecondPlayerPit = (boolean) isUserPit.invoke(kalahGameBoardFacade, 2, KalahGame.Player.SECOND_PLAYER);
        assertFalse(isSecondPlayerPit);
    }

    @Test
    public void testClearPit() throws Exception {
        gameBoard = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(gameBoard);
        Method clearPit = kalahGameBoard.getDeclaredMethod("clearSelectedPitStones", int.class, Map.class);
        privateMethodForTest(clearPit);
        clearPit.invoke(kalahGameBoardFacade, 3, gameBoard);
        assertEquals(0, gameBoard.get(3).intValue());

    }

    @Test
    public void testForAnotherTurnForPlayer() throws Exception {
        Method playerHasAnotherTurn = kalahGameBoard.getDeclaredMethod("hasAnotherTurnForPlayer", int.class, KalahGame.Player.class);
        privateMethodForTest(playerHasAnotherTurn);
        boolean first = (boolean) playerHasAnotherTurn.invoke(kalahGameBoardFacade, 7, KalahGame.Player.FIRST_PLAYER);
        boolean second = (boolean) playerHasAnotherTurn.invoke(kalahGameBoardFacade, 14, KalahGame.Player.SECOND_PLAYER);
        boolean invalid = (boolean) playerHasAnotherTurn.invoke(kalahGameBoardFacade, 12, KalahGame.Player.SECOND_PLAYER);
        assertTrue(first);
        assertTrue(second);
        assertFalse(invalid);
    }

    @Test
    public void testForGetOppositePit() throws Exception {
        Method getOppositePit = kalahGameBoard.getDeclaredMethod("getOppositePit", int.class);
        privateMethodForTest(getOppositePit);
        int opposite = (int) getOppositePit.invoke(kalahGameBoardFacade, 8);
        assertEquals(6, opposite);
    }

    @Test
    public void testForPutAllStonesToKalah() throws Exception {
        Method addStonesToKalah = kalahGameBoard.getDeclaredMethod("putAllStonesToKalah", KalahGame.Player.class, Map.class);
        privateMethodForTest(addStonesToKalah);

        gameBoard = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(gameBoard);
        addStonesToKalah.invoke(kalahGameBoardFacade, KalahGame.Player.FIRST_PLAYER, gameBoard);
        Integer totalStones = gameBoard.get(KalahGame.Player.FIRST_PLAYER.getKalahId());
        assertEquals(36, totalStones.intValue());
    }

    @Test
    public void testForPitsEmpty() throws Exception {
        Method arePitsEmpty = kalahGameBoard.getDeclaredMethod("arePitsEmpty", KalahGame.Player.class, Map.class);
        privateMethodForTest(arePitsEmpty);

        gameBoard = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(gameBoard);
        gameBoard.forEach((pit, value) -> {
            if (pit < KalahBoard.FIRST_KALAH_INDEX.getValue()) {
                gameBoard.put(pit, 0);
            }
        });
        boolean result = (boolean) arePitsEmpty.invoke(kalahGameBoardFacade, KalahGame.Player.FIRST_PLAYER, gameBoard);
        assertTrue(result);
    }

    @Test
    public void testForPopulateGameBoard() throws Exception {
        Method populateGameBoard = kalahGameBoard.getDeclaredMethod("populateGameBoard", int.class, KalahGame.class, Map.class, int.class);
        privateMethodForTest(populateGameBoard);

        gameBoard = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(gameBoard);
        KalahGame game = KalahGame.builder()
                .id(1234).board(gameBoard)
                .status(KalahGame.GameStatus.IN_PROGRESS)
                .player(KalahGame.Player.FIRST_PLAYER)
                .build();
        gameRepository.save(game);

        populateGameBoard.invoke(kalahGameBoardFacade, 2, game, gameBoard, 6);
        Integer totalStones = gameBoard.get(6);
        assertEquals(7, totalStones.intValue());
    }

    @Test
    public void testForPickOppositePitStonesToPlayerKalah() throws Exception {
        Method pickOppositePitStones = kalahGameBoard.getDeclaredMethod("pickOppositePitStonesToPlayerKalah", int.class, KalahGame.class, int.class);
        privateMethodForTest(pickOppositePitStones);

        gameBoard = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(gameBoard);
        KalahGame game = KalahGame.builder()
                .id(1234).board(gameBoard)
                .status(KalahGame.GameStatus.IN_PROGRESS)
                .player(KalahGame.Player.FIRST_PLAYER)
                .build();
        gameRepository.save(game);

        pickOppositePitStones.invoke(kalahGameBoardFacade, 2, game, 1);
        Integer totalStonesInOppositePit = gameBoard.get(12);
        Integer totalStonesInKalah = gameBoard.get(KalahBoard.FIRST_KALAH_INDEX.getValue());
        assertEquals(0, totalStonesInOppositePit.intValue());
        assertEquals(7, totalStonesInKalah.intValue());
    }

    @Test
    public void testForValidPitIndex() throws Exception {
        Method isValidPitIndex = kalahGameBoard.getDeclaredMethod("isValidPitIndex", int.class, KalahGame.class);
        privateMethodForTest(isValidPitIndex);

        gameBoard = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(gameBoard);
        KalahGame game = KalahGame.builder()
                .id(1234).board(gameBoard)
                .status(KalahGame.GameStatus.IN_PROGRESS)
                .player(KalahGame.Player.FIRST_PLAYER)
                .build();
        gameRepository.save(game);
        boolean validPit = (boolean) isValidPitIndex.invoke(kalahGameBoardFacade, 2, game);
        assertTrue(validPit);
        assertThatThrownBy(() -> isValidPitIndex.invoke(kalahGameBoardFacade, 0, game))
                .isInstanceOf(Exception.class);
    }

    @Test
    public void testForGameWinner() throws Exception {
        Method gameWinner = kalahGameBoard.getDeclaredMethod("gameWinner", KalahGame.class);
        privateMethodForTest(gameWinner);

        gameBoard = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(gameBoard);
        gameBoard.put(KalahBoard.FIRST_KALAH_INDEX.getValue(), 52);
        gameBoard.put(KalahBoard.SECOND_KALAH_INDEX.getValue(), 20);

        KalahGame game = KalahGame.builder()
                .id(1234).board(gameBoard)
                .status(KalahGame.GameStatus.IN_PROGRESS)
                .build();
        gameRepository.save(game);

        String winnerOfTheGame = (String) gameWinner.invoke(kalahGameBoardFacade, game);
        assertEquals(KalahGame.Player.FIRST_PLAYER.getName(), winnerOfTheGame);
    }

    @Test
    public void testForGameDraw() throws Exception {
        Method gameWinner = kalahGameBoard.getDeclaredMethod("gameWinner", KalahGame.class);
        privateMethodForTest(gameWinner);

        gameBoard = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(gameBoard);
        gameBoard.put(KalahBoard.FIRST_KALAH_INDEX.getValue(), 36);
        gameBoard.put(KalahBoard.SECOND_KALAH_INDEX.getValue(), 36);

        KalahGame game = KalahGame.builder()
                .id(1234).board(gameBoard)
                .status(KalahGame.GameStatus.IN_PROGRESS)
                .build();
        gameRepository.save(game);

        String draw = (String) gameWinner.invoke(kalahGameBoardFacade, game);
        assertEquals(KalahGame.GameStatus.DRAW.getGameStatus(), draw);
    }

    private void privateMethodForTest(Method method) {
        ReflectionUtils.makeAccessible(method);
    }
}
