package com.kalah.rest.repository;

import com.kalah.rest.model.KalahGame;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Repository interface for Kalah Game
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
public interface GameRepository {
    KalahGame save(final KalahGame game);

    Optional<KalahGame> findByGameId(int gameId);
}
