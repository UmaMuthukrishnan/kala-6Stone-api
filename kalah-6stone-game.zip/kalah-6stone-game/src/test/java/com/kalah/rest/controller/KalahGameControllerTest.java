package com.kalah.rest.controller;

import com.kalah.rest.model.KalahGame;
import com.kalah.rest.repository.GameRepository;
import com.kalah.rest.repository.InMemoryGameRepository;
import com.kalah.rest.service.KalahGameBoardFacade;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.web.context.WebApplicationContext;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

@RunWith(SpringRunner.class)
@WebMvcTest
public class KalahGameControllerTest {


    @Autowired
    private WebApplicationContext webApplicationContext;

    public MockMvc mockMvc;
    private final GameRepository gameRepository = InMemoryGameRepository.getInstance();

    @Before
    public void setUp() {

        this.mockMvc = webAppContextSetup(webApplicationContext).build();
    }

    @Test
    public void testCreateNewGame() throws Exception {
        mockMvc.perform(post("/games"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1));
    }

    @Test
    public void testToMoveStones() throws Exception {
        Map<Integer, Integer> board = new HashMap<>();
        KalahGameBoardFacade kalahGameBoardFacade = new KalahGameBoardFacade();
        kalahGameBoardFacade.initializeGameBoard(board);
        KalahGame game = KalahGame.builder()
                .id(1234).board(board)
                .status(KalahGame.GameStatus.IN_PROGRESS)
                .player(KalahGame.Player.FIRST_PLAYER)
                .build();
        gameRepository.save(game);

        mockMvc.perform(put("/games/1234/pits/3"))
                .andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print())
                .andExpect(jsonPath("$.id").value(1234))
                .andExpect(content().json("{\"status\":{\"1\":6,\"2\":6,\"3\":0,\"4\":7,\"5\":7,\"6\":7,\"7\":1,\"8\":7,\"9\":7,\"10\":6,\"11\":6,\"12\":6,\"13\":6,\"14\":0}}"));

    }

    @Test
    public void testToMoveStonesWithInvalidGameId() throws Exception {
        MvcResult result = mockMvc.perform(put("/games/0/pits/3")
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        assertTrue(content.contains("Enter a valid request"));
    }

    @Test
    public void testToMoveStonesWithInvalidPitId() throws Exception {
        MvcResult result = mockMvc.perform(put("/games/1/pits/0")
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andReturn();
        String content = result.getResponse().getContentAsString();
        assertTrue(content.contains("Enter a valid request"));
    }

}
