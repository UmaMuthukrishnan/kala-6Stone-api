package com.kalah.rest.controller;

import com.kalah.rest.exception.InvalidRequestException;
import com.kalah.rest.model.GameApiError;
import com.kalah.rest.response.MoveResponse;
import com.kalah.rest.response.NewGameResponse;
import com.kalah.rest.service.KalahGameService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Rest Controller class for Kalah Game API endpoints
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@RestController
@Slf4j
@RequestMapping("/games")
public class KalahGameController {

    private final KalahGameService kalahGameService;
    private static final String INVALID_GAME_REQUEST_ERROR_CODE = "GAME-API-001";
    private static final String INVALID_GAME_REQUEST_ERROR_DESC = "INVALID GAME REQUEST";

    @Autowired
    public KalahGameController(KalahGameService kalahGameService) {
        this.kalahGameService = kalahGameService;
    }

    /**
     * Creates a new Kalah Game
     *
     * @return persisted/created ResponseEntity<NewGameResponse> object with {id,uri} variables
     */
    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = " Creates a new 6-stone kalah game", response = NewGameResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Successfully created"),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<NewGameResponse> createNewGame() {
        log.info("-----To create newGame --------");
        return new ResponseEntity<>(kalahGameService.createNewGame(), HttpStatus.CREATED);
    }

    /**
     * Moves/ sows the stones inside the Kalah board by the player
     *
     * @param gameId Unique identifier of the game
     * @param pitId  Id of the selected Pit to make a move
     * @return updated ResponseEntity<MoveResponse> object with {id,url,status} variables
     */
    @PutMapping(value = "/{gameId}/pits/{pitId}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Make a successful move")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Updated "),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<MoveResponse> moveStones(@PathVariable int gameId, @PathVariable int pitId) {
        log.info("-----To make a move --------");
        if (gameId <= 0 || pitId <= 0) {
            throw new InvalidRequestException
                    (new GameApiError(INVALID_GAME_REQUEST_ERROR_CODE, INVALID_GAME_REQUEST_ERROR_DESC,
                            HttpStatus.BAD_REQUEST), "Enter a valid request");
        }

        return new ResponseEntity<>(kalahGameService.movePlayerPitStones(gameId, pitId), HttpStatus.OK);
    }
}
