package com.kalah.rest.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum KalahBoard {
    INITIAL_STONES(6),
    FIRST_PIT_INDEX(1),
    LAST_PIT_INDEX(13),
    FIRST_KALAH_INDEX(7),
    SECOND_KALAH_INDEX(14);
    private final int value;

}
