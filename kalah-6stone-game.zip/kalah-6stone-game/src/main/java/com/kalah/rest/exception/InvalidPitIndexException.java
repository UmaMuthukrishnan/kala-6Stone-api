package com.kalah.rest.exception;
/**
 * InvalidPitIndexException Class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
public class InvalidPitIndexException extends RuntimeException {

    public InvalidPitIndexException(String message) {
        super(message);
    }
}
