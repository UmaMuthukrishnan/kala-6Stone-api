package com.kalah.rest.mapper;

import com.kalah.rest.model.KalahGame;
import com.kalah.rest.response.MoveResponse;
import com.kalah.rest.response.NewGameResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.DefaultUriBuilderFactory;

import javax.servlet.http.HttpServletRequest;

/**
 * GameMapper Class to map the response object
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
public class GameMapper {

    private final HttpServletRequest request;

    @Autowired
    public GameMapper(HttpServletRequest request) {
        this.request = request;
    }

    /**
     * Mapper to map the game details to the NewResponse object
     *
     * @param game created game object
     * @return NewGameResponse object with {id,uri} variables
     */
    public NewGameResponse getNewGameResponse(KalahGame game) {
        return NewGameResponse.builder().id(String.valueOf(game.getId()))
                .uri(new DefaultUriBuilderFactory().builder()
                        .scheme(request.getScheme())
                        .host(request.getServerName())
                        .port(request.getServerPort())
                        .path("games/" + game.getId())
                        .build().toString()).build();
    }

    /**
     * Mapper to map the game details to the MoveResponse object
     *
     * @param game updated game object
     * @return MoveResponse object with {id,url status} variables
     */
    public MoveResponse getMovedGameResponse(KalahGame game) {
        return MoveResponse.builder()
                .id(String.valueOf(game.getId()))
                .status(game.getBoard())
                .url(new DefaultUriBuilderFactory().builder()
                        .scheme(request.getScheme())
                        .host(request.getServerName())
                        .port(request.getServerPort())
                        .path("games/" + game.getId())
                        .build().toString()).build();
    }

}
