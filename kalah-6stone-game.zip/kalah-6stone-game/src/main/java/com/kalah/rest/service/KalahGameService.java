package com.kalah.rest.service;

import com.kalah.rest.response.MoveResponse;
import com.kalah.rest.response.NewGameResponse;
/**
 * KalahGameService Interface for performing game actions
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
public interface KalahGameService {

    NewGameResponse createNewGame();
    MoveResponse movePlayerPitStones(int gameId,int pitId);
}
