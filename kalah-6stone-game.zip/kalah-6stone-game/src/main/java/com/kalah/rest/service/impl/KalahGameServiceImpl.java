package com.kalah.rest.service.impl;

import com.kalah.rest.exception.GameNotFoundException;
import com.kalah.rest.exception.GameTerminatedException;
import com.kalah.rest.mapper.GameMapper;
import com.kalah.rest.model.KalahGame;
import com.kalah.rest.repository.GameRepository;
import com.kalah.rest.repository.InMemoryGameRepository;
import com.kalah.rest.response.MoveResponse;
import com.kalah.rest.response.NewGameResponse;
import com.kalah.rest.service.KalahGameBoardFacade;
import com.kalah.rest.service.KalahGameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Service class for performing game actions
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Service
public class KalahGameServiceImpl implements KalahGameService {
    private final AtomicInteger randomInteger = new AtomicInteger(1);
    private final GameRepository gameRepository = InMemoryGameRepository.getInstance();
    private final GameMapper gameMapper;
    private final KalahGameBoardFacade kalahGameBoardFacade;

    @Autowired
    public KalahGameServiceImpl(GameMapper gameMapper, KalahGameBoardFacade kalahGameBoardFacade) {
        this.gameMapper = gameMapper;
        this.kalahGameBoardFacade = kalahGameBoardFacade;
    }

    /**
     * Method to create a new game entity
     *
     * @return persisted/created NewGameResponse object with
     * {id - unique identifier of game ,uri - hosting uri of the game} variables
     */
    @Override
    public NewGameResponse createNewGame() {
        Map<Integer, Integer> board = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(board);
        int gameId = randomInteger.getAndIncrement();
        KalahGame game = gameRepository.save(KalahGame.builder()
                .id(gameId).board(board)
                .status(KalahGame.GameStatus.IN_PROGRESS)
                .player(KalahGame.Player.FIRST_PLAYER)
                .build());
        return gameMapper.getNewGameResponse(game);
    }

    /**
     * Method for moving or sowing the stones inside the kalah board by the current player
     *
     * @param gameId unique identifier of game
     * @param pitId  unique identifier of player's pit
     * @return persisted/created MoveResponse object with
     * {id - unique identifier of game ,
     * uri - hosting uri of the game ,
     * status - moved game board status } variables
     */
    @Override
    public MoveResponse movePlayerPitStones(int gameId, int pitId) {
        KalahGame game = gameRepository.findByGameId(gameId).orElseThrow(() ->
                new GameNotFoundException("The given gameId :" + gameId + " is invalid"));
        if (game.getStatus() != KalahGame.GameStatus.IN_PROGRESS) {
            throw new GameTerminatedException("Game has already been terminated!");
        }
        kalahGameBoardFacade.movePitStones(pitId, game);
        KalahGame movedGame = gameRepository.save(game);
        return gameMapper.getMovedGameResponse(movedGame);
    }
}
