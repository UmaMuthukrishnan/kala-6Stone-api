package com.kalah.rest.response;

import lombok.*;

/**
 * Response class to handle created Kalah Game entity
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class NewGameResponse {
    private String id;
    private String uri;
}
