package com.kalah.rest.repository;

import com.kalah.rest.model.KalahGame;
import com.kalah.rest.service.KalahGameBoardFacade;
import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.junit.Assert.assertEquals;

@SpringBootTest
public class InMemoryGameRepositoryTest {
    private final GameRepository gameRepository = InMemoryGameRepository.getInstance();
    KalahGame kalahGame;

    @Before
    public void setUp() {
        KalahGameBoardFacade kalahGameBoardFacade = new KalahGameBoardFacade();
        Map<Integer, Integer> gameBoard = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(gameBoard);
        kalahGame = KalahGame.builder()
                .id(1234).board(gameBoard)
                .status(KalahGame.GameStatus.IN_PROGRESS)
                .player(KalahGame.Player.FIRST_PLAYER)
                .build();
        gameRepository.save(kalahGame);

    }

    @Test
    public void testForSave() {
        gameRepository.save(kalahGame);
        assertEquals(1234, kalahGame.getId());
        assertEquals(KalahGame.GameStatus.IN_PROGRESS, kalahGame.getStatus());
        assertEquals(KalahGame.Player.SECOND_PLAYER, kalahGame.getPlayer().getOppositePlayer());
    }

    @Test
    public void testForFindByValidGameId() {
        Optional<KalahGame> optionalKalahGame = gameRepository.findByGameId(1234);
        if (optionalKalahGame.isPresent()) {
            assertEquals(1234, optionalKalahGame.get().getId());
            assertEquals(KalahGame.GameStatus.IN_PROGRESS, optionalKalahGame.get().getStatus());
            assertEquals(KalahGame.Player.SECOND_PLAYER, optionalKalahGame.get().getPlayer().getOppositePlayer());
        }
    }

    @Test
    public void testForFindByInValidGameId() {
        assertEquals(Optional.empty(), gameRepository.findByGameId(0));
    }
}
