package com.kalah.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main class for KalahGameApplication
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@SpringBootApplication
public class KalahGameApplication {
    public static void main(String[] args) {
        SpringApplication.run(KalahGameApplication.class, args);
    }
}

