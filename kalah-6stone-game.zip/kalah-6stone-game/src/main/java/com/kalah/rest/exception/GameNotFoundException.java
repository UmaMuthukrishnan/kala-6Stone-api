package com.kalah.rest.exception;

/**
 * GameNotFoundException Class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
public class GameNotFoundException extends RuntimeException {

    public GameNotFoundException(String message) {
        super(message);
    }
}
