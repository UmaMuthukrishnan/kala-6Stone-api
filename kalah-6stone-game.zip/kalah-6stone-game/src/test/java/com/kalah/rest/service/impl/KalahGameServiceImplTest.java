package com.kalah.rest.service.impl;

import com.kalah.rest.exception.GameNotFoundException;
import com.kalah.rest.exception.GameTerminatedException;
import com.kalah.rest.mapper.GameMapper;
import com.kalah.rest.model.KalahGame;
import com.kalah.rest.repository.GameRepository;
import com.kalah.rest.repository.InMemoryGameRepository;
import com.kalah.rest.response.MoveResponse;
import com.kalah.rest.response.NewGameResponse;
import com.kalah.rest.service.KalahGameBoardFacade;
import com.kalah.rest.service.KalahGameService;
import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


@SpringBootTest
public class KalahGameServiceImplTest {

    private KalahGameService kalahGameService;

    private final GameRepository gameRepository = InMemoryGameRepository.getInstance();

    private KalahGameBoardFacade kalahGameBoardFacade;

    private Map<Integer, Integer> gameBoard;


    @Before
    public void setUp() {
        kalahGameBoardFacade = new KalahGameBoardFacade();
        MockHttpServletRequest request = new MockHttpServletRequest();
        GameMapper gameMapper = new GameMapper(request);
        kalahGameService = new KalahGameServiceImpl(gameMapper, kalahGameBoardFacade);
    }


    @Test
    public void testForCreateGame() {
        NewGameResponse gameResponse = kalahGameService.createNewGame();
        assertEquals("1", gameResponse.getId());
        assertNotNull(gameResponse.getUri());
        assertEquals("http://localhost:80/games/1", gameResponse.getUri());

    }

    @Test
    public void testToMovePlayerPitStones() {
        gameBoard = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(gameBoard);
        KalahGame game = KalahGame.builder()
                .id(1234).board(gameBoard)
                .status(KalahGame.GameStatus.IN_PROGRESS)
                .player(KalahGame.Player.FIRST_PLAYER)
                .build();
        gameRepository.save(game);

        MoveResponse moveResponse = kalahGameService.movePlayerPitStones(game.getId(), 3);
        assertEquals("1234", moveResponse.getId());
        assertNotNull(moveResponse.getUrl());
        assertEquals("http://localhost:80/games/1234", moveResponse.getUrl());
        assertEquals("{1=6, 2=6, 3=0, 4=7, 5=7, 6=7, 7=1, 8=7, 9=7, 10=6, 11=6, 12=6, 13=6, 14=0}", moveResponse.getStatus().toString());
        MatcherAssert.assertThat(moveResponse.getStatus(), CoreMatchers.is(game.getBoard()));
    }



    @Test
    public void testForMovePlayerPitStonesForGameOver() {
        Map<Integer, Integer> board = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(board);
        KalahGame game = KalahGame.builder()
                .id(1234).board(board)
                .status(KalahGame.GameStatus.GAME_OVER)
                .player(KalahGame.Player.FIRST_PLAYER)
                .build();
        gameRepository.save(game);
        assertThatThrownBy(() -> kalahGameService.movePlayerPitStones(1234, 3))
                .isInstanceOf(GameTerminatedException.class)
                .hasMessageContaining("Game has already been terminated!");


    }

    @Test
    public void testForMovePlayerPitStonesForInvalidGameId() {
        gameBoard = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(gameBoard);
        KalahGame game = KalahGame.builder()
                .id(1234).board(gameBoard)
                .status(KalahGame.GameStatus.IN_PROGRESS)
                .player(KalahGame.Player.FIRST_PLAYER)
                .build();
        KalahGame savedGame = gameRepository.save(game);
        assertThatThrownBy(() -> kalahGameService.movePlayerPitStones(savedGame.getId()+1, 3))
                .isInstanceOf(GameNotFoundException.class)
        .hasMessageContaining("The given gameId :1235 is invalid");


    }



}
