package com.kalah.rest.exception;

import com.kalah.rest.model.GameApiError;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * GenericException Handler for the API
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
@NoArgsConstructor
public class GenericException extends RuntimeException {

    private GameApiError gameApiError;

    public GenericException(String description) {
        super(description);
    }

    public GenericException(String description, Exception cause) {
        super(description, cause);
    }

    public GenericException(GameApiError gameApiError) {
        this.gameApiError = gameApiError;

    }

}
