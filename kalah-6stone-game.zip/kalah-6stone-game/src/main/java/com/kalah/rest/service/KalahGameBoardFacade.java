package com.kalah.rest.service;

import com.kalah.rest.exception.InvalidPitIndexException;
import com.kalah.rest.model.KalahGame;
import com.kalah.rest.model.enums.KalahBoard;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.stream.IntStream;

/**
 * KalahGameBoardFacade class for implementation of game actions
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
public class KalahGameBoardFacade {

    /**
     * Method to initialize the game board
     *
     * @param board board object to be initialized
     */
    public void initializeGameBoard(Map<Integer, Integer> board) {
        IntStream.rangeClosed(KalahBoard.FIRST_PIT_INDEX.getValue(), KalahBoard.SECOND_KALAH_INDEX.getValue())
                .forEach(pitId -> {
                    int firstPitIndex = KalahGame.Player.FIRST_PLAYER.getKalahId();
                    int secondPitIndex = KalahGame.Player.SECOND_PLAYER.getKalahId();
                    int value = (pitId != firstPitIndex && pitId != secondPitIndex) ? KalahBoard.INITIAL_STONES.getValue() : 0;
                    board.put(pitId, value);
                });
    }

    /**
     * Method to move pit stones
     *
     * @param pitId unique identifier of player pit
     * @param game  game entity
     */
    public void movePitStones(int pitId, KalahGame game) {
        if (isValidPitIndex(pitId, game)) {
            Map<Integer, Integer> board = game.getBoard();
            int stoneCount = board.get(pitId);
            clearSelectedPitStones(pitId, board);
            int lastIndex = pitId + stoneCount;
            int lastPit = lastIndex;
            lastIndex = populateGameBoard(pitId, game, board, lastIndex);
            lastPit = lastPit > KalahBoard.SECOND_KALAH_INDEX.getValue() ? lastIndex : lastPit;
            int stoneCountInLastPit = board.get(lastPit);
            if (stoneCountInLastPit == 1) {
                pickOppositePitStonesToPlayerKalah(lastPit, game, stoneCountInLastPit);
            }
            updateGameDetails(game, board, lastPit);
        }
    }

    /**
     * Method to update the game details
     *
     * @param game    game entity
     * @param board   game board entity
     * @param lastPit pit where the player's last stone lands
     */
    private void updateGameDetails(KalahGame game, Map<Integer, Integer> board, int lastPit) {
        if (!hasAnotherTurnForPlayer(lastPit, game.getPlayer())) {
            game.setPlayer(game.getPlayer().getOppositePlayer());
        } else {
            game.setPlayer(game.getPlayer());
        }
        game.setBoard(board);
        if (isGameTerminated(game)) {
            String winner = gameWinner(game);
            game.setWinner(winner);
            game.setStatus(KalahGame.GameStatus.GAME_OVER);
        }
    }

    /**
     * Method to populate the game board with player's stones
     *
     * @param pitId     unique identifier of player pit
     * @param game      game entity
     * @param board     board entity
     * @param lastIndex integer to be updated
     * @return calculated lastIndex based on player's stones
     */
    private int populateGameBoard(int pitId, KalahGame game, Map<Integer, Integer> board, int lastIndex) {
        for (int currentIndex = pitId + 1; currentIndex <= lastIndex; currentIndex++) {
            int currentPit = currentIndex;
            if (currentIndex == KalahBoard.SECOND_KALAH_INDEX.getValue() && lastIndex != KalahBoard.SECOND_KALAH_INDEX.getValue()) {
                lastIndex = lastIndex - currentIndex;
                currentIndex = 0;
            }
            if (game.getPlayer().getOppositePlayer().getKalahId() != currentPit) {
                int currentStonesInPit = board.get(currentPit);
                board.replace(currentPit, currentStonesInPit + 1);
            } else {
                if (currentIndex != KalahBoard.SECOND_KALAH_INDEX.getValue()) {
                    lastIndex++;
                } else {
                    lastIndex = KalahBoard.FIRST_PIT_INDEX.getValue();
                    currentIndex = 0;
                }
            }
        }
        return lastIndex;
    }

    /**
     * Method to clear the selected pit's stones
     *
     * @param pitId unique identifier of player pit
     * @param board game entity
     */
    private void clearSelectedPitStones(int pitId, Map<Integer, Integer> board) {
        board.replace(pitId, 0);
    }

    /**
     * Method to pick the opposite pit's stones once the last stone lands in player's own empty pit
     *
     * @param pitId      unique identifier of player pit
     * @param game       game entity
     * @param noOfStones stone which lands on last empty pit of player(=1)
     */
    private void pickOppositePitStonesToPlayerKalah(int pitId, KalahGame game, int noOfStones) {
        Map<Integer, Integer> board = game.getBoard();
        if (isUserPit(pitId, game.getPlayer())) {
            int oppositePit = getOppositePit(pitId);
            int oppositePitStoneCount = game.getBoard().get(oppositePit);
            clearSelectedPitStones(oppositePit, board);
            clearSelectedPitStones(pitId, board);
            int playerKalahId = game.getPlayer().getKalahId();
            int stonesInPlayerKalah = board.get(playerKalahId);
            int totalStones = stonesInPlayerKalah + oppositePitStoneCount + noOfStones;
            board.replace(playerKalahId, totalStones);
        }
    }

    /**
     * To check whether the current player has another turn to continue
     *
     * @param lastPitIndex pitid choosen by the current player last time
     * @param player       current player of the game
     * @return true if the player has other turn else false
     */
    private boolean hasAnotherTurnForPlayer(int lastPitIndex, KalahGame.Player player) {
        return player.getKalahId() == lastPitIndex;
    }

    /**
     * Method to get opposite pit number of given pit
     *
     * @param pitId pit id of the current player
     * @return pit id of the opposite player
     */
    private int getOppositePit(int pitId) {
        return KalahBoard.SECOND_KALAH_INDEX.getValue() - pitId;
    }

    /**
     * To check whether the selected pit is current player's pit
     *
     * @param pitId  pit id of the current player
     * @param player current player object
     * @return true if the pit id is of current player
     */
    private boolean isUserPit(int pitId, KalahGame.Player player) {
        return player.getPits().contains(pitId);
    }

    /**
     * Validate selected Pit index
     *
     * @param pitId pit id of the current player
     * @param game  KalahGame object
     */
    private boolean isValidPitIndex(int pitId, KalahGame game) {
        KalahGame.Player player = game.getPlayer();
        if (pitId == player.getKalahId() || pitId == player.getOppositePlayer().getKalahId()) {
            throw new InvalidPitIndexException("You cannot select the Kalahs!");
        }

        if (pitId < KalahBoard.FIRST_PIT_INDEX.getValue() || pitId > KalahBoard.LAST_PIT_INDEX.getValue()) {
            throw new InvalidPitIndexException("Given pitId is invalid...");
        }

        if (!isUserPit(pitId, player)) {
            throw new InvalidPitIndexException("This is not your turn!");
        }
        if (game.getBoard().get(pitId) == 0) {
            throw new InvalidPitIndexException("You can not select empty pit!");
        }
        return true;
    }

    /**
     * Method to verify whether the game is terminated
     *
     * @param game KalahGame entity
     * @return true if either of the player's pits ran out of stones else false
     */
    private boolean isGameTerminated(KalahGame game) {
        KalahGame.Player player = game.getPlayer();
        Map<Integer, Integer> board = game.getBoard();
        if (arePitsEmpty(player, board) || arePitsEmpty(player.getOppositePlayer(), board)) {
            putAllStonesToKalah(player, board);
            putAllStonesToKalah(player.getOppositePlayer(), board);
            return true;
        }
        return false;
    }

    /**
     * Method to check whether the player's pits are empty
     *
     * @param player current player
     * @param board  game board entity
     * @return true if the player's pits are empty else false
     */
    private boolean arePitsEmpty(KalahGame.Player player, Map<Integer, Integer> board) {
        return player.getPits().stream()
                .map(board::get)
                .allMatch(stoneNumbers -> stoneNumbers == 0);
    }

    /**
     * Method to put the stones in Player's Kalah
     *
     * @param player current player of the game
     * @param board  game board entity
     */
    private void putAllStonesToKalah(KalahGame.Player player, Map<Integer, Integer> board) {
        player.getPits().forEach(pit -> {
            int stonesInCurrentPit = board.get(pit);
            if (stonesInCurrentPit != 0) {
                int kalahId = player.getKalahId();
                board.replace(kalahId, board.get(kalahId) + stonesInCurrentPit);
                clearSelectedPitStones(pit, board);
            }
        });
    }

    /**
     * Method to get the Winner of the current game
     *
     * @param game current game entity
     * @return winner of the game
     */
    private String gameWinner(KalahGame game) {
        Map<Integer, Integer> board = game.getBoard();
        int firstPlayerStones = board.get(KalahGame.Player.FIRST_PLAYER.getKalahId());
        int secondPlayerStones = board.get(KalahGame.Player.SECOND_PLAYER.getKalahId());
        if (firstPlayerStones > secondPlayerStones) {
            return KalahGame.Player.FIRST_PLAYER.getName();
        } else if (firstPlayerStones < secondPlayerStones) {
            return KalahGame.Player.SECOND_PLAYER.getName();
        } else {
            return KalahGame.GameStatus.DRAW.getGameStatus();
        }
    }

}
