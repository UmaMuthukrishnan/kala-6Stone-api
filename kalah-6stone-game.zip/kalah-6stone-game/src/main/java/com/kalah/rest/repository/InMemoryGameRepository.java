package com.kalah.rest.repository;

import com.kalah.rest.model.KalahGame;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * InMemoryGameRepository Singleton for persisting the game details in-Memory
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
public class InMemoryGameRepository implements GameRepository {

    private static final InMemoryGameRepository instance = new InMemoryGameRepository();

    private final Map<Integer, KalahGame> inMemoryGameMap = new ConcurrentHashMap<>();

    public static InMemoryGameRepository getInstance() {
        return instance;
    }

    private InMemoryGameRepository() {
    }

    /**
     * Method to save the persisted/created details
     *
     * @param game game object to be created
     * @return persisted/created KalahGame entity
     */
    @Override
    public KalahGame save(KalahGame game) {
        inMemoryGameMap.put(game.getId(), game);
        return game;
    }

    /**
     * Method to look for already persisted KalahGame entity
     *
     * @param gameId unique identifier of game
     * @return Optional object of KalahGame type
     */
    @Override
    public Optional<KalahGame> findByGameId(int gameId) {
        if (gameId > 0) {
            return Optional.ofNullable(inMemoryGameMap.get(gameId));
        }
        return Optional.empty();
    }
}
