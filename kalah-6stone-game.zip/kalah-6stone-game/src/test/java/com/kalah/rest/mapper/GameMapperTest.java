package com.kalah.rest.mapper;

import com.kalah.rest.exception.GameNotFoundException;
import com.kalah.rest.model.KalahGame;
import com.kalah.rest.model.enums.KalahBoard;
import com.kalah.rest.repository.GameRepository;
import com.kalah.rest.repository.InMemoryGameRepository;
import com.kalah.rest.response.MoveResponse;
import com.kalah.rest.response.NewGameResponse;
import com.kalah.rest.service.KalahGameBoardFacade;
import org.hamcrest.CoreMatchers;
import org.hamcrest.MatcherAssert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

@SpringBootTest
public class GameMapperTest {

    private final GameRepository gameRepository = InMemoryGameRepository.getInstance();
    private GameMapper gameMapper;

    @Before
    public void setUp() {
        gameMapper = new GameMapper(new MockHttpServletRequest());
        KalahGameBoardFacade kalahGameBoardFacade = new KalahGameBoardFacade();
        Map<Integer, Integer> gameBoard = new HashMap<>();
        kalahGameBoardFacade.initializeGameBoard(gameBoard);
        KalahGame game = KalahGame.builder()
                .id(1234).board(gameBoard)
                .status(KalahGame.GameStatus.IN_PROGRESS)
                .player(KalahGame.Player.FIRST_PLAYER)
                .build();
        gameRepository.save(game);
    }

    @Test
    public void testForGetNewGameResponse() {
        KalahGame kalahGame = gameRepository.findByGameId(1234).orElseThrow(() ->
                new GameNotFoundException("The given gameId :" + 1234 + " is invalid"));
        NewGameResponse gameResponse = gameMapper.getNewGameResponse(kalahGame);
        assertEquals("1234", gameResponse.getId());
        assertEquals("http://localhost:80/games/1234", gameResponse.getUri());
    }

    @Test
    public void testForGetMovedGameResponse() {
        KalahGame kalahGame = gameRepository.findByGameId(1234).orElseThrow(() ->
                new GameNotFoundException("The given gameId :" + 1234 + " is invalid"));
        Map<Integer, Integer> existingBoard = kalahGame.getBoard();
        existingBoard.put(existingBoard.get(KalahBoard.FIRST_KALAH_INDEX.getValue()), 20);
        existingBoard.put(existingBoard.get(KalahBoard.SECOND_KALAH_INDEX.getValue()), 10);
        existingBoard.put(existingBoard.get(1), 2);
        kalahGame.setBoard(existingBoard);
        gameRepository.save(kalahGame);
        MoveResponse gameResponse = gameMapper.getMovedGameResponse(kalahGame);
        assertEquals("1234", gameResponse.getId());
        assertEquals("http://localhost:80/games/1234", gameResponse.getUrl());
        MatcherAssert.assertThat(gameResponse.getStatus(), CoreMatchers.is(kalahGame.getBoard()));
    }

}
