package com.kalah.rest.exception;

/**
 * GameTerminatedException Class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
public class GameTerminatedException extends RuntimeException {


    public GameTerminatedException(String message) {
        super(message);
    }
}
