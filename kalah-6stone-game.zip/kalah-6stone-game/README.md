## Technical stack requirements
Maven,
JDK 8,
Spring Boot 2.2.6,
In-Memory data structure(ConcurrentHashMap)


##Approach: 

 Created a Spring boot Application for exposing the API.
 For Data persistence,I have used the data structure,ConcurrentHashMap to store the game entity details in-memory as they are not so complex .

##About : Kalah Game API service
 
 This API serves to expose below two endpoints.
 
 i)CreateGame - For initializing and creating a new game.\
 ii)MoveStones - To move/sow the stones in gameboard pits and give the updated status of GameBoard.
 
Have implemented swagger to view the endpoints via

   http://localhost:8080/swagger-ui.html
   
##Accessing RestAPI endpoints

1.POST /games - To create a New Game,
       
 ```
 PostMan:
 curl --header "Content-Type: application/json" --request POST http://localhost:8080/kalah/games
 ```  
2.PUT /games/{gameId}/pits/{pitId} - To make a move,

 i)gameId - Unique game Id (Created above),\
 ii)pitId  - pit selected by the user.           
```
PostMan: 
curl --header "Content-Type: application/json" --request PUT http://localhost:8080/kalah/games/{gameId}/pits/{pitId}
```

This API is completely dockerized. Use docker-compose.yml file for running the application in docker.

# How to run
Download the source code in IDE  and execute:
```
mvn clean install
docker-compose build
docker-compose up
```