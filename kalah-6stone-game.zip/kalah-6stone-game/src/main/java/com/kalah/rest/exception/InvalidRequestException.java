package com.kalah.rest.exception;


import com.kalah.rest.model.GameApiError;
import lombok.Getter;


/**
 * InvalidRequestException Exception for the API
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
public class InvalidRequestException extends GenericException {

    String message;

    public InvalidRequestException(GameApiError gameApiError, String message) {
        super(gameApiError);
        this.message = message;

    }
}
